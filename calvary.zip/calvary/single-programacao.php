<?php get_header(); ?>
<div id="conteudo"> 	
<div id="wrapper"  >
	<div class="inner_bg" >
 			
            
            <div id="content" >
            
            
            <?php if(have_posts()) : ?>
					
			<?php while(have_posts()) : the_post() ?>
        
                <div id="post-<?php the_ID(); ?>" class="posts-devocional">
				    						                        
                    
					<div class="post_top">
										
                    <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                    
                    <p class="bege">Publicado em <?php the_time('j') ?> de <?php the_time('F, Y') ?><span><a href="<?php the_permalink(); ?>#commentarea"><?php comments_number('Comente!', '1 Coment&aacute;rio', '% Coment&aacute;rios'); ?></a></span></p>
                            
                    
                    </div>
                    
                    <?php the_content(); ?>
											
                </div><!--/post-->  

				<div id="comments"><?php comments_template(); ?></div>
        
            <?php endwhile; ?>
			
			<div class="pagination">
			
                <?php if (function_exists('wp_pagenavi')) { ?><?php wp_pagenavi(); ?><?php } ?>
						
            </div>
			
             <?php endif; ?>
			
 
	   </div> <!-- content #end -->
        
        
		<?php get_sidebar(); ?>
		
        
   </div> <!-- innerbg #end -->
   <div class="end"></div>
   </div>

<?php get_footer(); ?>
