<?php get_header(); ?>
<div id="conteudo"> 	
 <div id="wrapper">
  <div class="inner_bg" >
    <div id="content" >
      <?php if(have_posts()) : ?>
 			<?php while(have_posts()) : the_post() ?>
        
                <div id="post-<?php the_ID(); ?>" class="posts-mensagens">
                
                <div class="esquerda"><p>Publicado em <?php the_time('j') ?> de <?php the_time('F, Y') ?></p></div>
                
                <div class="direita">
                	
                	<div class="comente">
                		<a href="<?php the_permalink(); ?>#commentarea"><?php comments_number('Comente!', '1 Coment&aacute;rio', '% Coment&aacute;rios'); ?></a>
                	</div>
                	
                	<div class="share">
                		<span>Compartilhe via:</span>
                			<ul>
                				<li><a class="share facebook" href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&t=<?php the_title(); ?>" target="_blank"></a></li>
								<li><a class="share twitter" href="http://twitter.com/home/?status=<?php the_permalink(); ?>"target="_blank"></a></li>
							</ul>
						</div>
					</div>
					
					<div class="clear"></div>
                    
                    <h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
					
					<?php the_content(); ?>
					
						<div class="download">
							<a href="<?php echo get_post_meta($post->ID, "download", true); ?>">Download</a>
						</div>
											
                </div><!--/post-->

				<div id="comments"><?php comments_template(); ?></div>
        
            <?php endwhile; ?>
			
			<div class="pagination">
			
                <?php if (function_exists('wp_pagenavi')) { ?><?php wp_pagenavi(); ?><?php } ?>
						
            </div>
			
             <?php endif; ?>
			
 
	   </div> <!-- content #end -->
        
        
		<?php get_sidebar(); ?>
		
        
   </div> <!-- innerbg #end -->
   <div class="end"></div>
   </div>

<?php get_footer(); ?>
