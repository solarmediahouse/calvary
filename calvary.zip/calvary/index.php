<?php
/*
Template Name: Home Page
*/
?>
<?php
if($_REQUEST['page']=='thumb')
{
	$_REQUEST['w'] = $_REQUEST['width'];
	include(TEMPLATEPATH . '/thumb.php');
	exit;
}
?>
<?php get_header(); ?>

<div id="conteudo">
<div id="wrapper">

 <div id="slide-banner">
 <?php if ( function_exists( 'meteor_slideshow' ) ) { meteor_slideshow(); } ?>
 </div> <!-- slide banner #end -->

<div id="ultimo-estudo">
<?php $recent = new WP_Query("cat=7&showposts=1"); while($recent->have_posts()) : $recent->the_post();?>
<div class="titulo">
<h2><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
<span><p class="postmetadata"><?php the_time('j') ?> de <?php the_time('F, Y') ?></span>
</div>
<div class="player"><?php the_content(); ?></div>
<div class="download"><a href="<?php echo get_post_meta($post->ID, "download", true); ?>">Download</a></div>
<?php endwhile; ?>
</div>



<div class="bemvindo">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Boas Vindas'));  ?>
</div>  


<div class="devocional">
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Nossa Devocional'));  ?>
</div>

<div class="infos">
	<div class="reunioes">
		<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Reuni&otilde;es'));  ?>
	</div>
	 <div class="clear"></div>
	<div class="localizacao">
		<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Localiza&ccedil;&atilde;o'));  ?>
	</div>
 </div>
</div><div class="clear"></div>
</div>

<?php get_footer(); ?>    
      