<?php get_header(); ?>

<div id="conteudo"> 
<div id="wrapper"  >
	<div class="inner_bg inner_bg_full" >
 			<div class="tituloin"><h1 class="head"><?php the_title(); ?></h1></div>
            
            <div id="content" class="content_full" >
                  
            	
                     	
		<?php if(have_posts()) : ?>
			<?php while(have_posts()) : the_post() ?>
            		<?php $pagedesc = get_post_meta($post->ID, 'pagedesc', $single = true); ?>
            
        
                    <div id="post-<?php the_ID(); ?>" class="posts bnone" >
                         
                            <?php the_content(); ?>
                         
                    </div><!--/post-->
                
            <?php endwhile; else : ?>
        
                    <div class="posts">
                        <div class="entry-head"><h2><?php echo get_option('ptthemes_404error_name'); ?></h2></div>
                        <div class="entry-content"><p><?php echo get_option('ptthemes_404solution_name'); ?></p></div>
                    </div>
        
        <?php endif; ?>
        
	  </div> <!-- content #end -->
        
        
	 
		
        
   </div> <!-- innerbg #end -->
   <div class="end"></div>
   </div>
   </div>

<?php get_footer(); ?>