<?php
$post = $wp_query->post;
if (in_category('mensagens')) {
	include (TEMPLATEPATH.'/archive-mensagens.php');
	return;
}
if (in_category('programacao')) {
	include (TEMPLATEPATH.'/archive-programacao.php');
	return;
}
if (in_category('devocionais')) {
	include (TEMPLATEPATH.'/archive-devocional.php');
	return;
}
get_header(); ?>