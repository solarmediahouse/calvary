<div id="sidebar" >
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar Contato'));  ?> 
</div><!-- sidebar #end -->