<div id="sidebar" >
<?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Sidebar Programa&ccedil;&atilde;o'));  ?>                	
</div><!-- sidebar #end -->