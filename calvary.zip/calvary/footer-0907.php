<div id="bottom">
<div id="footer">
         	<div class="fleft">
            <?php if (function_exists('dynamic_sidebar') && dynamic_sidebar('Info Rodap&eacute;'));  ?>
           </div>
           
           <div class="right">
            <p>Redes Sociais: </p>
            <ul>
            <li class="facebook"><a href="http://www.facebook.com/profile.php?id=100002237784649" title="facebook" target="_blank"> Facebook </a></li>
            <li class="twitter"><a href="http://twitter.com/calvarycampo" title="Twitter" target="_blank"> Twitter </a></li>
            <li class="youtube"><a href="javascript:void(0)" title="Youtube"> Youtube </a></li>
            </ul>
           </div>
        </div><!-- footer #end -->
     </div><!-- bottom #end -->

 <?php wp_footer(); ?>

</body>

</html>
		