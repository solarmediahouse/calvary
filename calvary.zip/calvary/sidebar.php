<?php
$post = $wp_query->post;
if (in_category('mensagens')) {
	include (TEMPLATEPATH.'/sidebar-mensagens.php');
	return;
}
if (in_category('programacao')) {
	include (TEMPLATEPATH.'/sidebar-programacao.php');
	return;
}
if (in_category('devocionais')) {
	include (TEMPLATEPATH.'/sidebar-devocional.php');
	return;
}
if (is_page('contato')) {
	include (TEMPLATEPATH.'/sidebar-contato.php');
	return;
}
get_header(); ?>