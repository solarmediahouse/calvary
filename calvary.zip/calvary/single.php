<?php
$post = $wp_query->post;
if (in_category('mensagens')) {
	include (TEMPLATEPATH.'/single-mensagens.php');
	return;
}
if (in_category('programacao')) {
	include (TEMPLATEPATH.'/single-programacao.php');
	return;
}
if (in_category('devocionais')) {
	include (TEMPLATEPATH.'/single-devocional.php');
	return;
}
get_header(); ?>